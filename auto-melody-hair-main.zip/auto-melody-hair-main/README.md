 Melody hair Mod, auto melody hair, hypixel skyblock how to complete melody hair, melody harp, Melody hypixel skyblock Macro

## [Download](https://github.com/zazornik221/auto-melody-hair/releases/download/AutoHarp/AutoHarp.jar)

This mod will automatically play [Melody]'s harp. 
Requirements: Minecraft 1.8.9 + Forge 

# This mod will completely complete Melody's Hair 100%.
## HOW TO OPEN GUI?

rShift

## ⚠️ Disclaimer

**This mod might violate Hypixel rules. I am not responsible for any action that Hypixel takes against you!**

## Double notes not supported

This means that you need to play the double notes of:

```
Hymn to the Joye
Joy to the World
La Vie en Rose
Through the Campfire
```


